#include <iostream>

using namespace std;

int main()
{
	cout << {{flag}} << endl;
	return 0;
}