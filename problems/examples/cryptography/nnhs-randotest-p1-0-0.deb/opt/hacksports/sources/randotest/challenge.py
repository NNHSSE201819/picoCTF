from hacksport.problem_templates import CompiledBinary
Problem = CompiledBinary(sources=["vuln.c"])
