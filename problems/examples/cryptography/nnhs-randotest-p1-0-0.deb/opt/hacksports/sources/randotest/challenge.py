from hacksport.problem_templates import CompiledBinary
Problem = CompiledBinary(sources=["myproblem.cpp"])
