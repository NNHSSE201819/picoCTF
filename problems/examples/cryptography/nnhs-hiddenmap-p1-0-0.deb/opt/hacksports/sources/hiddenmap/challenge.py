from hacksport.problem_templates import CompiledBinary
Problem = CompiledBinary(sources=["vuln.c"], static_flag="")
