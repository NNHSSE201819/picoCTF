from hacksport.problem_templates import CompiledBinary
Problem = CompiledBinary(sources=["vuln.c"], flag_file="key", aslr=True, remote=True)
